<?php
define("DB_HOST", "localhosst");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "website_kiddem");
?>