<section class="admin-content">
        <div class="admin-content-left">
            <ul>
                <li><a href="#">Danh mục</a></li>
                <ul>
                    <li><a href="cartegoryadd.php">Thêm danh mục</a></li>
                    <li><a href="cartegorylist.php">Danh sách danh mục</a></li>
                </ul>
                <li><a href="#">Lọại sản phẩm</a></li>
                <ul>
                    <li><a href="brandadd.php">Thêm loại sản phẩm</a></li>
                    <li><a href="brandlist.php">Danh sách loại sản phẩm</a></li>
                </ul>
                <li><a href="#">Sản phẩm</a></li>
                <ul>
                    <li><a href="productadd.php">Thêm sản phẩm</a></li>
                    <li><a href="productlist.php">Danh sách sản phẩm</a></li>
                </ul>
            </ul>
        </div>