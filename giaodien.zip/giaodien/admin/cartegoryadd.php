<?php
include "header.php";
include "slider.php";
include "class/cartegory_class.php"
?>
<?php
    $cartegory = new cartegory;
    if($_SERVER['REQUEST_METHOD']=== 'POST'){
        $cartegory_name=$_POST['cartegory_name'];
        $insert_cartegory = $cartegory ->insert_cartegory($cartegory_name);
    }
?>

<div class="admin-content-right">
            <div class="admin-content-right-cartegory_add">
                <h1>Thêm danh mục</h1>
                <form action=""method="POST">
                    <select name="" id="">
                        <option value="#">--Chọn danh mục</option> 
                        <option value="">TẤT CẢ</option>
                        <option value="">BÉ TRAI</option>
                        <option value="">BÉ GÁI</option>
                        <option value="">ĐỒ SƠ SINH</option>
                        <option value="">PHỤ KIỆN-ĐỒ CHƠI</option>
                    </select> 
                    <input required name="cartegory_name" type="text" placeholder="Nhập tên danh mục">
                    <button type="submit">Thêm</button>
                </form>

                </form>
            </div>
        </div>
    </section>
</body>
</html>